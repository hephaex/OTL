# OTL - Ontology-based Knowledge System

[![CI](https://github.com/hephaex/OTL/actions/workflows/ci.yml/badge.svg)](https://github.com/hephaex/OTL/actions/workflows/ci.yml)
[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![Rust](https://img.shields.io/badge/rust-1.75%2B-orange.svg)](https://www.rust-lang.org/)

**OTL** (Ontology-based knowledge sysTem Library) is a high-performance knowledge management system that combines **ontology-based knowledge graphs** with **Retrieval-Augmented Generation (RAG)** to provide accurate, contextual answers from organizational documents.

## 🎯 Key Features

- **Hybrid Search**: Combines vector similarity, graph traversal, and keyword search
- **Ontology-Based**: Explicit semantic relationships between concepts
- **Access Control**: Document-level ACL for enterprise security
- **Multi-Format Support**: PDF, DOCX, XLSX, PPTX, Markdown, and more
- **OCR Integration**: Process scanned documents
- **Human-in-the-Loop**: Verification workflow for knowledge extraction
- **Citation Tracking**: Every answer includes source references

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         OTL System                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  [Documents] → [Parser] → [Chunker] → [Extractor] → [Graph]    │
│                                           ↓                     │
│                                    [HITL Verify]               │
│                                           ↓                     │
│  [Question] → [RAG Orchestrator] → [Hybrid Search] → [LLM]     │
│                     ↓                     ↓            ↓        │
│              [Vector DB]          [Graph DB]    [Answer + Citation]
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 🚀 Quick Start

### Prerequisites

- Rust 1.75+
- Docker & Docker Compose
- PostgreSQL 15+
- SurrealDB 2.0+
- Qdrant 1.10+

### Installation

```bash
# Clone the repository
git clone https://github.com/hephaex/OTL.git
cd OTL

# Start infrastructure
docker compose up -d

# Build the project
cargo build --release

# Run migrations
cargo run -p otl-cli -- migrate

# Start the API server
cargo run -p otl-api
```

### CLI Usage

```bash
# Ingest documents
otl ingest ./documents/

# Query the knowledge base
otl query "What is the vacation request procedure?"

# Verify extracted knowledge
otl verify list
otl verify approve <extraction-id>

# Export ontology
otl ontology export --format owl
```

### API Usage

```bash
# Query endpoint
curl -X POST http://localhost:8080/api/v1/query \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"question": "How do I request vacation?"}'

# Response
{
  "answer": "To request vacation, follow these steps: ...",
  "citations": [
    {"index": 1, "document_title": "HR Policy 2024", "page": 15}
  ],
  "confidence": 0.92
}
```

## 📁 Project Structure

```
OTL/
├── crates/
│   ├── otl-core/       # Domain models, traits, ACL
│   ├── otl-parser/     # Document parsing (PDF, DOCX, etc.)
│   ├── otl-ocr/        # OCR integration
│   ├── otl-graph/      # Graph database abstraction
│   ├── otl-vector/     # Vector database abstraction
│   ├── otl-extractor/  # NER and relation extraction
│   ├── otl-rag/        # RAG orchestrator
│   ├── otl-api/        # REST/gRPC API
│   └── otl-cli/        # Command-line interface
├── deploy/
│   ├── kubernetes/     # K8s manifests
│   └── argocd/         # ArgoCD application
├── docs/
│   ├── Gemini.md       # Project definition
│   └── SPRINT_PLAN.md  # Implementation roadmap
└── ontologies/         # OWL ontology definitions
```

## 🔧 Configuration

Create a `.env` file or use environment variables:

```bash
# Database connections
DATABASE_URL=postgres://user:pass@localhost:5432/otl
SURREALDB_URL=ws://localhost:8000
QDRANT_URL=http://localhost:6334

# LLM configuration
LLM_PROVIDER=openai  # or "ollama"
OPENAI_API_KEY=sk-...
OLLAMA_URL=http://localhost:11434

# Server settings
API_HOST=0.0.0.0
API_PORT=8080
LOG_LEVEL=info
```

## 📊 Performance Targets

| Metric | Target |
|:---|:---|
| Search Precision@5 | ≥ 85% |
| Hallucination Rate | ≤ 5% |
| Response Time (p95) | ≤ 3s |
| Data Integration | ≥ 70% |

## 🔐 Security

OTL implements document-level access control:

- **Public**: Anyone can access
- **Internal**: Organization members only
- **Confidential**: Specific roles/departments
- **Restricted**: Named individuals only

All queries are filtered based on the authenticated user's permissions.

## 🛣️ Roadmap

- [x] Core architecture design
- [x] Document parsing pipeline
- [ ] Knowledge extraction with HITL
- [ ] Hybrid RAG implementation
- [ ] REST API
- [ ] Web UI
- [ ] Multi-tenant support

See [SPRINT_PLAN.md](docs/SPRINT_PLAN.md) for detailed implementation timeline.

## 🤝 Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) first.

```bash
# Development workflow
cargo fmt           # Format code
cargo clippy        # Lint
cargo test          # Run tests
cargo doc --open    # Generate docs
```

## 📄 License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## 📬 Contact

- Author: hep@gmail.com
- Repository: https://github.com/hephaex/OTL
- Issues: https://github.com/hephaex/OTL/issues

---

Built with 🦀 Rust
